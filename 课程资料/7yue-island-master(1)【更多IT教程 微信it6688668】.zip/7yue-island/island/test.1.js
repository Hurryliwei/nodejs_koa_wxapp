const a = -1
const v = {
    [a]:200
}

console.log(v)