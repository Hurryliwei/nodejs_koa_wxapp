
module.exports = {
    // prod
    environment:'dev',
    database:{
        dbName:'7yue',
        host:'localhost',
        port:3306,
        user:'root',
        password:'123456',
    },
}