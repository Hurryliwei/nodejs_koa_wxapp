
def demo4(**param):
    print(param)
    for key, value in param:
        print(key, ':', value)


# demo4(ab=1, cd=2, ed=5)

demo4(abc=1,cde=2)
