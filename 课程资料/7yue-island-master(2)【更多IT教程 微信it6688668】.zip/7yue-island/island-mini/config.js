
const config = {
    api_base_url: 'http://localhost:3000/v1/',
    // appkey: "请访问www.7yue.pro获取开发者key",
}



export {config }
